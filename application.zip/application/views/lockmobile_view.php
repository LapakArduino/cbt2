<div class="container">
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Gunakan Exam Browser
        <small> Gunakan Exam Browser untuk mengakses Aplikasi Ujian Online</small>
    </h1>
</section>

<!-- Main content -->
<section class="content">
    <div class="callout callout-info">
        <h4>Informasi</h4>
        <p>Untuk mengakses Aplikasi Ujian Online ZYACBT menggunakan Android, gunakanlah Exam Browser</p>
		<p>Download <a href="<?php echo base_url(); ?>public/apk/aplikasi-ujian-online-zyacbt.apk" >Exam Browser</a></p>
    </div>
</section><!-- /.content -->
</div>

<script type="text/javascript">
    $(function () {
        
    });
</script>