<div class="container">
<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Browser yang Di Dukung
        <small> Browser yang didukung aplikasi</small>
    </h1>
</section>

<!-- Main content -->
<section class="content">
    <div class="callout callout-info">
        <h4>Informasi</h4>
        <p>Untuk mengakses Aplikasi Ujian Online ZYACBT, gunakan salah satu dari browser berikut melalui perangkat komputer PC ataupun Laptop : Mozilla Firefox, Google Chrome, Safari, atau Opera.
		</p>
    </div>
</section><!-- /.content -->
</div>

<script type="text/javascript">
    $(function () {
        
    });
</script>